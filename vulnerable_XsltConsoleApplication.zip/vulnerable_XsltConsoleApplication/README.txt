Execute XsltConsoleApplication.exe in a command prompt.

The application expects (in the current working directory):
 - an XML file (data.xml) and
 - an XSLT style sheet (transform.xslt)


Source code is in "src"