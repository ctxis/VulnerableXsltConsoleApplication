﻿using System;
using System.Xml;
using System.Xml.Xsl;

namespace XsltConsoleApplication
{
    class Program
    {
        /*
        This code contains serious vulnerabilities and is provided for training purposes only!
        DO NOT USE ANYWHERE FOR ANYTHING ELSE!!!
        */
        static void Main(string[] args)
        {
            Console.WriteLine("\n#####################################################################");
            Console.WriteLine("#                                                                   #");
            Console.WriteLine("# This is a Vulnerable-by-Design application to test XSLT Injection #");
            Console.WriteLine("#                                                                   #");
            Console.WriteLine("#####################################################################\n");
            Console.WriteLine("The application expects (in the current working directory):");
            Console.WriteLine(" - an XML file (data.xml) and\n - an XSLT style sheet (transform.xslt)\n");
            Console.WriteLine("===================================================================");

            String transformationXsltFileURI = "transform.xslt";
            String dataXMLFileURI = "data.xml";

            // Enable DTD processing to load external XML entities for both the XML and XSLT file
            XmlReaderSettings vulnerableXmlReaderSettings = new XmlReaderSettings();
            vulnerableXmlReaderSettings.DtdProcessing = DtdProcessing.Parse;
            vulnerableXmlReaderSettings.XmlResolver = new XmlUrlResolver();
            XmlReader vulnerableXsltReader = XmlReader.Create(transformationXsltFileURI, vulnerableXmlReaderSettings);
            XmlReader vulnerableXmlReader = XmlReader.Create(dataXMLFileURI, vulnerableXmlReaderSettings);

            XsltSettings vulnerableSettings = new XsltSettings();
            // Embedded script blocks and the document() function are NOT enabled by default
            vulnerableSettings.EnableDocumentFunction = true;
            vulnerableSettings.EnableScript = true;
            // A vulnerable settings class can also be created with:
            // vulnerableSettings = XsltSettings.TrustedXslt;

            XslCompiledTransform vulnerableTransformation = new XslCompiledTransform();
            // XmlUrlResolver is the default resolver for XML and XSLT and supports the file: and http: protocols
            XmlUrlResolver vulnerableResolver = new XmlUrlResolver();
            vulnerableTransformation.Load(vulnerableXsltReader, vulnerableSettings, vulnerableResolver);

            XmlWriter output = new XmlTextWriter(Console.Out);

            // Run the transformation
            vulnerableTransformation.Transform(vulnerableXmlReader, output);

        }
    }
}
